def Say( *args, **kwargs ):
  print( *args, **kwargs )











def Quiet():
  pass
