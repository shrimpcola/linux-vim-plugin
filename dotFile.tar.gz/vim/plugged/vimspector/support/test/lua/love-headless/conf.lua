function love.conf(t)
    t.modules.audio = false
    t.modules.font = false
    t.modules.graphics = false
    t.modules.image = false
    t.modules.mouse = false
    t.modules.physics = false
    t.modules.sound = false
    t.modules.touch = false
    t.modules.video = false
    t.modules.window = false
end
