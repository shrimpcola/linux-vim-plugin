Before you create an issue, please read and follow the troubleshooting steps [listed here](https://github.com/Chiel92/vim-autoformat#help-the-formatter-doesnt-work-as-expected).
